﻿namespace EasyStudy.Shared.Data;

public interface IGroupRepository
{
    
}