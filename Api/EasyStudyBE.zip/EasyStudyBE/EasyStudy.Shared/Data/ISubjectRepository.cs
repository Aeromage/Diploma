﻿namespace EasyStudy.Shared.Data;

public interface ISubjectRepository
{
    
}