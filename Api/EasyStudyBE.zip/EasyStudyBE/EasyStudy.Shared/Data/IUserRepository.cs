﻿using EasyStudy.Shared.Entities.Domain;

namespace EasyStudy.Shared.Data;

public interface IUserRepository : IRepository<User>
{
    
}