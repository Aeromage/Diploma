﻿using EasyStudy.Shared.Entities;
using EasyStudy.Shared.Entities.Domain;

namespace EasyStudy.Shared.Data;

public interface IGradeRepository : IRepository<Grade>
{
    
}