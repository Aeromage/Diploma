﻿namespace EasyStudy.Shared.Data;

public interface IStudentRepository
{
    
}