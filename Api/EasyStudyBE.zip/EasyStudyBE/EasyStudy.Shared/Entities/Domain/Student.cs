﻿namespace EasyStudy.Shared.Entities.Domain;

public class Student : User
{
    public Group Group { get; set; }
}