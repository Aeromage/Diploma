﻿namespace EasyStudy.Shared.Entities.Domain;

public enum Role
{
    Admin,
    Teacher,
    Student
}