﻿namespace EasyStudy.Shared.Entities;

public class BaseEntity
{
    public int Id { get; set; }
    
    public bool IsArchived { get; set; }
}